export function parsePlaylistSnapshot(value) {
    try {
        const data = JSON.parse(value);
        if (data === null || typeof data !== "object" ||
            typeof data.active !== "boolean" ||
            (data.previous !== null && typeof data.previous !== "string") ||
            (data.current !== null && typeof data.current !== "string") ||
            !Array.isArray(data.queue) ||
            !data.queue.every((file) => typeof file === "string")) {
            return null;
        }
        return data;
    }
    catch {
        return null;
    }
}
