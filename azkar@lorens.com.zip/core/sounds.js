/**
 * core/sounds.ts — Azkar Audio Manifest
 *
 * Responsibility:
 * - Maintain a strictly typed registry of all bundled MP3 assets.
 * - Safely generate absolute paths and URIs for GStreamer ingestion.
 */
import GLib from "gi://GLib";
// Ensure these match the files bundled by the Makefile[cite: 3, 5].
const BUNDLED_SOUNDS = [
    "al_bahr.mp3",
    "al_balad.mp3",
    "al_rahman.mp3",
    "kaf.mp3",
    "khazayen_1.mp3",
    "khazayen_2.mp3",
    "khazayen_3.mp3",
    "mn_kan_yered_al_aza.mp3",
    "naziat.mp3",
    "noah.mp3",
    "sabikon_al_sabikon.mp3",
    "sabr_gamil.mp3",
    "salat_ful.mp3",
    "salat_tahajud.mp3",
    "salat.mp3",
    "w_asber.mp3",
    "yom_al_kiyama.mp3",
    "akhi1.mp3",
    "akhi2.mp3",
    "akhi3.mp3",
    "akhi4.mp3",
    "goraba1.mp3",
    "goraba2.mp3",
    "hamhama1.mp3",
    "hamhama2.mp3",
    //"iza1_1.mp3",
    //"iza2_1.mp3",
    //"iza2_2.mp3",
    //"iza2_3.mp3",
    //"omati1.mp3",
    //"omati2.mp3",
    //"omati3.mp3",
    "samedon1.mp3",
    //"samedon2.mp3",
    "afant.mp3",
    "al_rahman_1.mp3",
    "gorabn.mp3",
    "kadar.mp3",
    "subhan.mp3",
    "ya_hay_ya_kayom.mp3",
    "aboab_alsmaa.mp3",
    "la_amlik.mp3",
    "la_tkono.mp3",
    "zakariya.mp3",
];
/**
 * Hydrates the audio manifest with safe system paths.
 */
export function getSoundsData(extensionPath) {
    const data = { sounds: {}, soundNames: [] };
    for (const file of BUNDLED_SOUNDS) {
        // Strip extension for the dictionary key
        const name = file.replace(".mp3", "");
        // Safely construct the path via GLib
        const soundPath = GLib.build_filenamev([extensionPath, "src", "sounds", file]);
        // Generate the file:// URI for GStreamer
        const [soundUri] = GLib.filename_to_uri(soundPath, null);
        data.sounds[name] = {
            soundName: name,
            soundFile: file,
            soundPath,
            soundUri,
        };
        data.soundNames.push(name);
    }
    return data;
}
