/**
 * core/soundRandomizer.ts — Randomized Audio Scheduler
 */
import GLib from "gi://GLib";
import Gio from "gi://Gio";
import { Logger } from "../utils/logger.js";
import { AudioPlayer } from "./audioPlayer.js";
import { getSoundsData } from "./sounds.js";
export class SoundRandomizer {
    _audioPlayer;
    _soundsData;
    _settings;
    _unplayedSounds = [];
    _timerId = null;
    _isActive = false;
    _settingsSignalId = 0;
    _listener = null;
    _upcomingSound = null;
    _periodMinutes = 60;
    PRE_ACTIVE_LEAD_TIME_SEC = 10;
    constructor(audioPlayer, extensionPath, settings) {
        this._audioPlayer = audioPlayer;
        this._settings = settings;
        this._soundsData = getSoundsData(extensionPath);
        this._resetQueue();
        this._settingsSignalId = this._settings.connect('changed::scheduler-period', () => {
            if (this._isActive) {
                Logger.info("Interval changed. Restarting scheduler pipeline...");
                this.restart();
            }
        });
    }
    setListener(listener) {
        this._listener = listener;
    }
    _resetQueue() {
        this._unplayedSounds = [...this._soundsData.soundNames];
        // Fisher-Yates Shuffle
        for (let i = this._unplayedSounds.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this._unplayedSounds[i], this._unplayedSounds[j]] =
                [this._unplayedSounds[j], this._unplayedSounds[i]];
        }
    }
    restart() {
        const periodMinutes = this._settings.get_int("scheduler-period");
        this.start(periodMinutes);
    }
    /**
     * Manual start invoked by UI/Extension Init. Clears all existing state.
     */
    start(periodMinutes) {
        this.stop();
        this._isActive = true;
        this._periodMinutes = periodMinutes;
        Logger.info(`Scheduler started: Next Azkar in ${periodMinutes} min.`);
        this._scheduleIdleWait();
    }
    /**
     * Phase 1: Idle Wait (Period minus 10 seconds)
     */
    _scheduleIdleWait() {
        const periodSeconds = this._periodMinutes * 60;
        const waitTimeSeconds = Math.max(1, periodSeconds - this.PRE_ACTIVE_LEAD_TIME_SEC);
        this._timerId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, waitTimeSeconds, () => {
            if (!this._isActive)
                return GLib.SOURCE_REMOVE;
            this._prepareNextSound();
            this._schedulePreActive();
            return GLib.SOURCE_REMOVE;
        }, null);
    }
    /**
     * Phase 2: Pre-Active Countdown (10 seconds)
     */
    _schedulePreActive() {
        this._timerId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, this.PRE_ACTIVE_LEAD_TIME_SEC, () => {
            if (!this._isActive)
                return GLib.SOURCE_REMOVE;
            this._playPreparedSound();
            // Start the next cycle's waiting period IMMEDIATELY, 
            // but DO NOT call stop() on the currently playing audio!
            this._scheduleIdleWait();
            return GLib.SOURCE_REMOVE;
        }, null);
    }
    stop() {
        this._isActive = false;
        // CLEANUP: Unregister GLib source
        if (this._timerId !== null) {
            GLib.Source.remove(this._timerId);
            this._timerId = null;
        }
        this._audioPlayer.stop();
        if (this._listener)
            this._listener.onRandomizerStopped();
        Logger.info("Scheduler stopped.");
    }
    _prepareNextSound() {
        if (this._unplayedSounds.length === 0)
            this._resetQueue();
        const nextSoundName = this._unplayedSounds.pop();
        if (!nextSoundName)
            return;
        this._upcomingSound = this._soundsData.sounds[nextSoundName];
        Logger.info(`Entering Pre-Active state. Scheduled: ${this._upcomingSound.soundName}`);
        if (this._listener) {
            this._listener.onPreActive(this._upcomingSound, this.PRE_ACTIVE_LEAD_TIME_SEC);
        }
    }
    _playPreparedSound() {
        if (!this._upcomingSound)
            return;
        Logger.info(`Playback Started: ${this._upcomingSound.soundName}`);
        if (this._listener)
            this._listener.onSoundStarted(this._upcomingSound);
        this._audioPlayer.play(`src/sounds/${this._upcomingSound.soundFile}`);
        this._upcomingSound = null; // Clear the buffer
    }
    destroy() {
        this.stop();
        if (this._settingsSignalId > 0) {
            this._settings.disconnect(this._settingsSignalId);
            this._settingsSignalId = 0;
        }
        this._unplayedSounds = [];
        this._listener = null;
    }
}
